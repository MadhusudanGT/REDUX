export const BUG_ADDED="bugAdded";
export const BUG_REMOVED="bugRemoved";
export const BUG_RESLOVED="bugResloved";